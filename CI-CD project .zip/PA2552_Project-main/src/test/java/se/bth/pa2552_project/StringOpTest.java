package se.bth.pa2552_project;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringOpTest {

    //Author: Varshitha Pamisetty
    //Description: This test is to test the concatStrings() function
    @Test
    void concatStringsTest(){
        assertEquals(StringOp.concatStrings("Software","Testing"),"SoftwareTesting");
    }

    //Author: Varshitha Pamisetty
    //Description: This test is to test the reverseString() function
    @Test
    void reverseStringTest(){
        assertEquals(StringOp.reverseString("Hello world"),"dlrow olleH");
    }

    //Author:Varshitha Pamisetty
    //Description: This test is to test the countOccurenceOfCharacter() function
    @Test
    void countOccurenceofCharTest(){
        assertEquals(StringOp.countOccurenceOfCharacter("Hello world",'l'),3);
    }

    //Author: Varshitha Pamisetty
    //Description: This is an integration test including the functions-
    // concatStrings(), reverseString(), countOccurenceOfCharacter()
    @Test
    void integrationTest1(){
        //first perform the test for concatStrings() and store it in res1
        String res1 = StringOp.concatStrings("Python","Programming Language");
        // res1 = PythonProgramming Language
        // give res1 as input to the reverseString() function and test it
        String res2 = StringOp.reverseString(res1);
        // res2 = egaugnaL gnimmargorPnohtyP
        // give res2 as input to the countOccurenceOfCharacter() function to test it
        int res3 = StringOp.countOccurenceOfCharacter(res2,'n');
        // res3 = 3, since n occurs thrice in it
        //now we test the final outcome with the calculated value
        assertEquals(StringOp.countOccurenceOfCharacter("PythonProgramming Language",'n'),res3);
    }

    //Author Sree Kavya Ganja
    //Description: this test case is used to find out the number of words present in a given sentence.
    @Test
    void countNumberofCharacters(){
        assertEquals(StringOp.countNumberofCharacters("Hello"), 1);
    }

    //Author Sree Kavya Ganja
    //Description: This test case is used to reverse given string using string formatter method.
    @Test
    void revStringUsingStringFormatter(){
        assertEquals(StringOp.revStringUsingStringFormatter("Hello"), "olleH");
    }


    //Author Sree Kavya Ganja
    //Description: this test case is used to reverse the string using string concat method.
    @Test
    void reverseWithStringConcat(){
        assertEquals(StringOp.reverseWithStringConcat("Hello"), "olleH");
    }


    //Author Sree Kavya Ganja
    //the integration test is performed on the following functions
    //reverseWithStringConcat(), revStringUsingStringFormatter() and countNumberofCharaters().
    @Test
    void integrationTest2(){
        // first I am going to include the concatString function in the integration test case.

        String res1 = StringOp.reverseWithStringConcat("Hello");

        String res2 = StringOp.revStringUsingStringFormatter(res1);

        int res3 = StringOp.countNumberofCharacters(res2);

        assertEquals(StringOp.countNumberofCharacters("Hello"), res3);
    }


    // Author Harsha Gangadhara Vinay kumar Donga
    // this test is to test the lower case string function-

    @Test
    void toLowerTest(){
        assertEquals(StringOp.LowerCase("HEllo WoRld"),"hello world");
    }

    //this test is to test the upper case string function-

    @Test
    void toUppertest(){
        assertEquals(StringOp.UpperCase("Hello World"),"HELLO WORLD");
    }

    //this test is to test the count of words function-

    @Test
    void countWords(){
        assertEquals(StringOp.countWords("Hello World"),2);
    }
    @Test
    void IntegrationTest3()
    {
        String res1 = StringOp.LowerCase("CLouD clOUD comPUTIng");
        // res1--cloud cloud computing
        String res2 = StringOp.UpperCase(res1);
        // res2--CLOUD CLOUD COMPUTING
        int res3 = StringOp.countWords(res2);
                //we now test the final outcome with the calculated value
        assertEquals(StringOp.countWords("CLouD clOUD ComPUTIng"),res3);
    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Tests if we can insert a string out-of-bounds
    @Test
    void StringInsertTestOutOfBounds()
    {
        Exception error = assertThrows(Exception.class, () ->{StringOp.StringInsert("hello", "Luke", 15);});

        assertTrue(error.getMessage().contains("Position is out of bounds!"));
    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Tests inserting a string into a given position
    @Test
    void StringInsertTest() throws Exception {
        assertEquals("Who am I?", StringOp.StringInsert("Who  I?", "am", 4));
    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Tests removing characters from an out-of-bounds position
    @Test
    void CharacterRemoveTestOutOfBounds()
    {
        //We assert for a throw as we want to manage an exception
        Exception error = assertThrows(Exception.class, () ->{StringOp.CharacterRemove("hello", 10);});

        // We also would like to check that the error message is correct
        assertTrue(error.getMessage().contains("Position is out of bounds!"));
    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Tests removing characters from a given position
    @Test
    void CharacterRemoveTest() throws Exception {
        //Here we test the actual functionality of the code
        assertEquals("hell", StringOp.CharacterRemove("hello", 4));
    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Integration test of removing and adding characters
    @Test
    void IntegrationTestAddingAndRemovingCharacters() throws Exception {
        // The base string
        String sentence = "Hello general Kenobi!";

        // Lets add a word
        sentence = StringOp.StringInsert(sentence, "there ", 6);
        // Then remove some characters
        for (int i = 0; i < 8; i++) {
            sentence = StringOp.CharacterRemove(sentence, sentence.length() - 1);
        }
        // Check the result
        assertEquals("Hello there general", sentence);
    }
}