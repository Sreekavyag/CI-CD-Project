open module se.bth.pa2552_project {
    exports se.bth.pa2552_project;
}