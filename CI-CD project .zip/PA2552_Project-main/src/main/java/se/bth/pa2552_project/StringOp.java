package se.bth.pa2552_project;

import java.lang.reflect.Executable;
import java.util.Locale;

public class StringOp {

    public static short LowerCase;

    //Author: Varshitha Pamisetty
    //Description:This function returns the concatenated string by joining the two given input strings
    //This function is tested by the unit test "concatStringsTest()"
    public static String concatStrings(String s1,String s2){
        //initialize the resultant string
        String res="";
        //concatenate the given two strings and store them in res
        res = s1.concat(s2);
        return res;
    }

    //Author:Varshitha Pamisetty
    //Description: The function returns the given string in a reversed manner.
    //This function is tested by the unit test "reverseStringTest()"
    public static String reverseString(String str){
        char ch=' ';
        String newStr="";
        for(int i=0;i < str.length();i++){
            //extracting each character from the string
            ch = str.charAt(i);
            //adds a new character infront of the newly created empty string
            newStr = ch + newStr;
        }
        return newStr;
    }

    //Author: Varshitha Pamisetty
    //Description: The function returns the occurence of the specified letter in the word.
    //This function is tested by the unit test "countOccurenceofCharTest()"
    public static int countOccurenceOfCharacter(String str,char ch){
        //count the occurence of the character again
        int res = 0;
        for(int i = 0;i < str.length();i++){
            //checking the given character in the string
            if(str.charAt(i) == ch){
                res++;
            }
        }
        return res;
    }

    // Sree Kavya Ganja
    // Description: This function returns the no of words present in the given sentence.
    // This test case is tested by the unit test "countNoofCharactersTest.
    public static int countNumberofCharacters(String str){
        int count = 1;
        for(int i = 0; i < str.length() - 1; i++)
        {
            if((str.charAt(i) == ' ') && (str.charAt(i+1) != ' '))
            {
                count++;
            }
        }
        return count;
    }


    // Sree Kavya Ganja
    // Description: This function returns the reversed string using String Formatter function.
    // This test case is tested by the unit test "revStringUsingStringFormatter".
    public static String revStringUsingStringFormatter(String str){
        StringBuilder sb=new StringBuilder(str);
        sb.reverse();
        return sb.toString();
    }


    // Sree Kavya Ganja
    // Description: This function returns the reversed string using String Concatination function.
    // This test case is tested by the unit test "reverseWithStringConcat".
    public static String reverseWithStringConcat(String string){
        String output = new String();
        for(int i = (string.length() - 1); i >= 0; i--){
            output += (string.charAt(i));
        }
        return output;
    }


    // Harsha gangadhara Vinay kumar Donga
    // Description : This function returns the following word into small letters

    public static String LowerCase(String str){
        String newRes = str.toLowerCase();
        return newRes;
    }

    // Description :This function returns the following word into Upper letters

    public static String UpperCase(String str){
        String newRes = str.toUpperCase();
        return newRes;
    }

    //Description: This Function returns the count of words
    public static int countWords(String str){
        int count =1;
        for (int i=0;i<str.length()-1;i++){
            if((str.charAt(i)==' ')&&(str.charAt(i+1)!=' ')){
                count++;
            }
        }
        return count;

    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Allows the user to insert a string into a given position
    public static String StringInsert(String baseString, String insertString, int position) throws Exception {
        if (position < 0 || position > baseString.length()) {
            throw new Exception("Position is out of bounds!");
        }
        return baseString.substring(0, position) + insertString + baseString.substring(position);
    }

    //Author: Stephanie Sundqvist Tepfers
    //Description: Allows the user to remove a character from a given position
    public static String CharacterRemove(String baseString, int position) throws Exception {
        // First we make sure we can handle the exception, the text has to match as well
        if(position < 0 || position > baseString.length())
        {
            throw new Exception("Position is out of bounds!");
        }
        // Once we handle all exceptions, we can now perform the task at hand
        return baseString.substring(0,position) + baseString.substring(position + 1);
    }
}
